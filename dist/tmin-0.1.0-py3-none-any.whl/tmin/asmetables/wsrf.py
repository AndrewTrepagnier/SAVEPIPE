
WSRF = { # weld strength reduction factor, Provide Farenheit and returns weld factor, W
        '1250': 0.73,
        '1300' : 0.68,
        '1350': 0.63,
        '1400': 0.59,
        '1450': 0.55,
        '1500': 0.5
    }